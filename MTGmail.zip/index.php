  <html>
  <head>
    <title>Mail test sending</title>
  </head>
  <body>
    <form action="send.php" method="GET">

      <input name="to"></input>
      <input name="subject"></input>
      <input name="main"></input>
      <input type="submit">

      
    </form>
  </body>
</html>